# painel-slides
Tema para painel do novo sga (www.novosga.org)
