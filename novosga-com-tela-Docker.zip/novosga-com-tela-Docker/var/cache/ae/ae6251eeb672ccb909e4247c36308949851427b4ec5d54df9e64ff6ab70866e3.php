<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* index.html.twig */
class __TwigTemplate_35e09c5266d127c422a8c2f634357fb802d109c968106a1cd607196ebde880af extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'moduleContent' => [$this, 'block_moduleContent'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "module.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("module.html.twig", "index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_moduleContent($context, array $blocks = [])
    {
        // line 3
        echo "<div id=\"monitor\">
    <form class=\"form-inline\" role=\"search\" onsubmit=\"return false\">
        <div class=\"form-group\">
            <input type=\"text\" id=\"buscar-senha\" class=\"form-search form-control\" placeholder=\"";
        // line 6
        echo gettext("buscar senha");
        echo "\" />
        </div>
        <button id=\"btn-open-consulta\" class=\"btn btn-primary\" onclick=\"SGA.Monitor.Senha.consulta()\">
            <span class=\"glyphicon glyphicon-search\"></span>&nbsp;
            ";
        // line 10
        echo gettext("Consultar");
        // line 11
        echo "        </button>
    </form>
    ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["servicos"]) ? $context["servicos"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["su"]) {
            // line 14
            echo "    <div id=\"servico-";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["su"], "servico", []), "id", []), "html", null, true);
            echo "\" class=\"servico empty\" data-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["su"], "servico", []), "id", []), "html", null, true);
            echo "\">
        <span class=\"title\">";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($context["su"], "sigla", []), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["su"], "servico", []), "nome", []), "html", null, true);
            echo "</span>
        <ul class=\"fila\">
        </ul>
    </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['su'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "</div>

";
        // line 23
        echo "<div id=\"dialog-busca\" class=\"modal fade\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                <h4 class=\"modal-title\">";
        // line 28
        echo gettext("Busca");
        echo "</h4>
            </div>
            <div class=\"modal-body\">
                <form class=\"form-inline\" role=\"form\" onsubmit=\"return false\">
                    <div class=\"form-group\">
                        <input id=\"numero_busca\" type=\"text\" maxlength=\"5\" class=\"form-search form-control\" placeholder=\"";
        // line 33
        echo gettext("Número");
        echo "\" />
                    </div>
                    <button id=\"btn-consultar\" class=\"btn btn-primary\" onclick=\"SGA.Monitor.Senha.consultar()\">";
        // line 35
        echo gettext("Consultar");
        echo "</button>
                </form>
                <div class=\"result\">
                    <table id=\"result_table\" class=\"table\">
                        <thead>
                            <tr>
                                <th>";
        // line 41
        echo gettext("Número");
        echo "</th>
                                <th>";
        // line 42
        echo gettext("Serviço");
        echo "</th>
                                <th>";
        // line 43
        echo gettext("Data chegada");
        echo "</th>
                                <th>";
        // line 44
        echo gettext("Data início");
        echo "</th>
                                <th>";
        // line 45
        echo gettext("Data fim");
        echo "</th>
                                <th>";
        // line 46
        echo gettext("Triagem");
        echo "</th>
                                <th>";
        // line 47
        echo gettext("Atendente");
        echo "</th>
                                <th>";
        // line 48
        echo gettext("Situação");
        echo "</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

";
        // line 61
        echo "<div id=\"dialog-view\" class=\"modal fade\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                <h4 class=\"modal-title\">";
        // line 66
        echo gettext("Atendimento");
        echo "</h4>
            </div>
            <div class=\"modal-body\">
                <input id=\"senha_id\" type=\"hidden\" />
                <fieldset>
                    <legend>";
        // line 71
        echo gettext("Senha|Bilhete");
        echo "</legend>
                    <div>
                        <label>";
        // line 73
        echo gettext("Número");
        echo "</label>
                        <span id=\"senha_numero\"></span>
                    </div>
                    <div>
                        <label>";
        // line 77
        echo gettext("Prioridade");
        echo "</label>
                        <span id=\"senha_prioridade\"></span>
                    </div>
                    <div>
                        <label>";
        // line 81
        echo gettext("Serviço");
        echo "</label>
                        <span id=\"senha_servico\"></span>
                    </div>
                    <div>
                        <label>";
        // line 85
        echo gettext("Data chegada");
        echo "</label>
                        <span id=\"senha_chegada\"></span>
                    </div>
                    <div>
                        <label>";
        // line 89
        echo gettext("Tempo de espera");
        echo "</label>
                        <span id=\"senha_espera\"></span>
                    </div>
                    <div>
                        <label>";
        // line 93
        echo gettext("Data início");
        echo "</label>
                        <span id=\"senha_inicio\"></span>
                    </div>
                    <div>
                        <label>";
        // line 97
        echo gettext("Data fim");
        echo "</label>
                        <span id=\"senha_fim\"></span>
                    </div>
                    <div>
                        <label>";
        // line 101
        echo gettext("Situação");
        echo "</label>
                        <span id=\"senha_status\"></span>
                    </div>
                </fieldset>
                <fieldset>
                    <legend>";
        // line 106
        echo gettext("Cliente");
        echo "</legend>
                    <div>
                        <label>";
        // line 108
        echo gettext("Nome");
        echo "</label>
                        <span id=\"cliente_nome\"></span>
                    </div>
                    <div>
                        <label>";
        // line 112
        echo gettext("Documento");
        echo "</label>
                        <span id=\"cliente_documento\"></span>
                    </div>
                </fieldset>
            </div>
            <div class=\"modal-footer\">
                <button id=\"btn-reativar\"
                        class=\"btn btn-primary\"
                        onclick=\"SGA.Monitor.Senha.reativar(\$('#senha_id').val())\">
                    ";
        // line 121
        echo gettext("Reativar senha");
        // line 122
        echo "                </button>
                <button id=\"btn-transferir\"
                        class=\"btn btn-default\"
                        onclick=\"SGA.Monitor.Senha.transfere(\$('#senha_id').val(), \$('#senha_numero').text())\">
                    ";
        // line 126
        echo gettext("Transferir / Alterar senha");
        // line 127
        echo "                </button>
                <button id=\"btn-cancelar\"
                        class=\"btn btn-danger\"
                        onclick=\"SGA.Monitor.Senha.cancelar(\$('#senha_id').val())\">
                    ";
        // line 131
        echo gettext("Cancelar senha");
        // line 132
        echo "                </button>
            </div>
        </div>
    </div>
</div>

";
        // line 139
        echo "<div id=\"dialog-transfere\" class=\"modal fade\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                <h4 class=\"modal-title\">";
        // line 144
        echo gettext("Tranferir Senha");
        echo "</h4>
            </div>
            <div class=\"modal-body\">
                <input id=\"transfere_id\" type=\"hidden\" />
                <div class=\"form-group\">
                    <label>";
        // line 149
        echo gettext("Senha|Bilhete");
        echo "</label>
                    <span id=\"transfere_numero\"></span>
                </div>
                <div class=\"form-group\">
                    <label for=\"transfere_servico\">";
        // line 153
        echo gettext("Novo serviço");
        echo "</label>
                    <select id=\"transfere_servico\" class=\"form-control\">
                        ";
        // line 155
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["servicos"]) ? $context["servicos"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["su"]) {
            // line 156
            echo "                        <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["su"], "servico", []), "id", []), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["su"], "servico", []), "nome", []), "html", null, true);
            echo "</option>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['su'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 158
        echo "                    </select>
                </div>
                <div class=\"form-group\">
                    <label>";
        // line 161
        echo gettext("Nova prioridade");
        echo "</label>
                    <select id=\"transfere_prioridade\" class=\"form-control\">
                        ";
        // line 163
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["prioridades"]) ? $context["prioridades"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["prioridade"]) {
            // line 164
            echo "                        <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["prioridade"], "id", []), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["prioridade"], "nome", []), "html", null, true);
            echo "</option>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['prioridade'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 166
        echo "                    </select>
                </div>
            </div>
            <div class=\"modal-footer\">
                <button id=\"btn-transferir\"
                        class=\"btn btn-primary\"
                        onclick=\"SGA.Monitor.Senha.transferir()\">
                    ";
        // line 173
        echo gettext("Transferir");
        // line 174
        echo "                </button>
            </div>
        </div>
    </div>
</div>


<div id=\"sga-clock\" title=\"";
        // line 181
        echo gettext("Data e hora no servidor");
        echo "}\"></div>
<script type=\"text/javascript\">
    \$('.servico').each(function(i,v) {
        var servico = \$(v);
        SGA.Monitor.ids.push(servico.data('id'));
    });
    SGA.Clock.init(\"sga-clock\", ";
        // line 187
        echo twig_escape_filter($this->env, (isset($context["milis"]) ? $context["milis"] : null), "html", null, true);
        echo ");
    SGA.Monitor.alertCancelar = '";
        // line 188
        echo gettext("Deseja realmente cancelar essa senha?");
        echo "';
    SGA.Monitor.alertReativar = '";
        // line 189
        echo gettext("Deseja realmente reativar essa senha?");
        echo "';
    SGA.Monitor.init();
</script>
";
    }

    public function getTemplateName()
    {
        return "index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  391 => 189,  387 => 188,  383 => 187,  374 => 181,  365 => 174,  363 => 173,  354 => 166,  343 => 164,  339 => 163,  334 => 161,  329 => 158,  318 => 156,  314 => 155,  309 => 153,  302 => 149,  294 => 144,  287 => 139,  279 => 132,  277 => 131,  271 => 127,  269 => 126,  263 => 122,  261 => 121,  249 => 112,  242 => 108,  237 => 106,  229 => 101,  222 => 97,  215 => 93,  208 => 89,  201 => 85,  194 => 81,  187 => 77,  180 => 73,  175 => 71,  167 => 66,  160 => 61,  145 => 48,  141 => 47,  137 => 46,  133 => 45,  129 => 44,  125 => 43,  121 => 42,  117 => 41,  108 => 35,  103 => 33,  95 => 28,  88 => 23,  84 => 20,  71 => 15,  64 => 14,  60 => 13,  56 => 11,  54 => 10,  47 => 6,  42 => 3,  39 => 2,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "index.html.twig", "/var/www/html/novosga/modules/sga/monitor/views/index.html.twig");
    }
}
