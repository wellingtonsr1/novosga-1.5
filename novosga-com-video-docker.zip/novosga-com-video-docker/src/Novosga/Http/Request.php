<?php

namespace Novosga\Http;

/**
 * Request Wrapper.
 *
 * @author Rogerio Lino <rogeriolino@gmail.com>
 */
class Request extends \Slim\Http\Request
{
    public function __construct()
    {
    }
}
